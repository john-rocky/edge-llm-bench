<!-- written by scripts/dashboard_post.py for a person; removed when the dir is committed -->
# REVIEW: 2026-10-18-dashboard-v1-pixel8a-ddp-akita-35-android — FAIL

Held by scripts/dashboard_post.py at 2026-10-18 14:42 UTC: nothing of this sitting was committed.

Why: 2026-10-18-dashboard-v1-pixel8a-ddp-akita-35-android FAIL (rules: failures, logcat-unscrubbed, runner-exit); a sitting is committed whole or not at all

The dirs of this post: 2026-10-18-dashboard-v1-pixel8a-ddp-akita-35-android FAIL

| severity | rule | detail | what a person does |
|---|---|---|---|
| FAIL | `logcat-unscrubbed` | ddp/session-4b783529/j01-gpu-Qwen3-1-7B-short-chat/execution-5935005c-7bd5-4ebe-a12a-b3392904aa64/logcat.txt (untracked): the execution-level logcat.txt stays out of every commit | scrub the logcat (android/ddp/scrub.py), keep execution-level logcat.txt out, post again |
| HOLD | `runner-exit` | runner_exit 1 | read the job log's tail for the runner's exit before calling the sitting clean |
| HOLD | `failures` | litert-lm-gpu litert-community/Qwen3-1.7B short-chat context-tokens=default file=Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm ddp=akita-35 session=session-4b783529 job=j01-gpu-Qwen3-1-7B-short-chat execution=5935005c-7bd5-4ebe-a12a-b3392904aa64 result=FAILED clean=1/2 (cell records in the dir: 1) | read FAILURES.txt and the cell's log: re-run the cell, or commit by hand with the reason |

Not holding:
- `gen-budget`: litert-lm-gpu litert-community/Qwen3-1.7B short-chat (v0.18.0): 1 of 1 runs generated past the budget (526>128) — allowed by dad937b1 (litert_lm_main decodes past --max_output_tokens (b6ddcb2c on v0.16.0; v0.18.0 the same, DDP 536-1039 and attached 566-790 tokens): only the DDP route's records name the budget, so only its short-chat cells meet the rule)

Post again once it is fixed (the allow-list takes a line only when a commit message gives the reason):

    python3 scripts/dashboard_post.py results/raw/2026-10-18-dashboard-v1-pixel8a-ddp-akita-35-android

A dir that cannot pass is committed by hand with the reason in the message (docs/dashboard-recurring-job-v1.md §6), or stays uncommitted.
